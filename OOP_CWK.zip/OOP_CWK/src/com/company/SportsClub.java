package com.company;

public class SportsClub {
	private String nameOfClub;
	private String locationOfCLub;

	public SportsClub(String nameOfClub, String locationOfCLub) {
		this.nameOfClub = nameOfClub;
		this.locationOfCLub = locationOfCLub;
	}

	public String getNameOfClub() {
		return nameOfClub;
	}

	public void setNameOfClub(String nameOfClub) {
		this.nameOfClub = nameOfClub;
	}

	public String getLocationOfCLub() {
		return locationOfCLub;
	}

	public void setLocationOfCLub(String locationOfCLub) {
		this.locationOfCLub = locationOfCLub;
	}


}
